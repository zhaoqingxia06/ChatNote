(() => {
  'use strict';
  // Compare content, never timestamps. Preserve disk bytes when only line endings differ.
  const comparable = text => String(text ?? '').replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const same = (a, b) => comparable(a) === comparable(b);
  function decide(base, local, disk) {
    if (same(local, disk)) return 'equal';
    if (base === undefined) return 'conflict'; // Unknown history must never overwrite an existing file.
    if (same(disk, base)) return 'push';
    if (same(local, base)) return 'pull';
    return 'conflict';
  }
  const api = {same, decide};
  globalThis.ChatNoteSync = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
