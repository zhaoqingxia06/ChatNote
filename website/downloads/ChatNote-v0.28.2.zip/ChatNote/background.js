let queue = Promise.resolve();
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  const trusted = sender.url && (/^https:\/\/(chatgpt\.com|chat\.openai\.com)\//.test(sender.url) || sender.url.startsWith(chrome.runtime.getURL('')));
  if (!trusted) return;
  if (!['read', 'write', 'nativeSaved', 'nativeDeleted'].includes(m.type) || typeof m.key !== 'string' || !m.key.startsWith('article:')) return;
  queue = queue.catch(() => {}).then(async () => {
    const stored = (await chrome.storage.local.get(m.key))[m.key] || null;
    if (m.type === 'nativeSaved') {
      if (!stored || stored.deleted || m.created !== undefined && m.created !== stored.created || (Number(m.syncedRevision) || 0) < (stored.syncedRevision || 0)) return {
        ok: false
      };
      stored.lastSaved = Date.now();
      stored.savedFileName = String(m.savedFileName || stored.savedFileName || '');
      stored.savedFolderName = String(m.savedFolderName || stored.savedFolderName || '');
      stored.savedFolderId = String(m.savedFolderId || stored.savedFolderId || '');
      stored.syncedRevision = Number(m.syncedRevision) || stored.syncedRevision || 0;
      await chrome.storage.local.set({
        [m.key]: stored
      });
      return {
        ok: true,
        savedAt: stored.lastSaved
      };
    }
    if (m.type === 'read') return {
      ok: true,
      doc: stored
    };
    if ((stored?.revision || 0) !== m.revision) return {
      ok: false,
      conflict: true,
      doc: stored
    };
    if (m.type === 'nativeDeleted') {
      if (!stored || stored.savedFileName !== m.savedFileName || stored.savedFolderId !== m.savedFolderId) return {ok:false, conflict:true};
      // A tombstone invalidates stale writes from other tabs without retaining deleted content.
      const doc = {deleted:true, html:'', md:'', title:'', revision:stored.revision + 1, updated:Date.now()};
      await chrome.storage.local.set({[m.key]:doc});
      return {ok:true, doc};
    }
    const doc = {
      deleted: false,
      fileNameManual: !!m.doc.fileNameManual,
      savedFileName: stored?.savedFileName || '',
      savedFolderName: stored?.savedFolderName || '',
      savedFolderId: stored?.savedFolderId || '',
      syncedRevision: stored?.syncedRevision || 0,
      lastSaved: stored?.lastSaved || null,
      fileName: Array.from(String(m.doc.fileName || stored?.fileName || '未命名文档').replace(/[\\/:*?"<>|\x00-\x1f]/g, '').replace(/\s+/g, '')).slice(0, 8).join('') || '未命名文档',
      created: stored?.created || stored?.updated || Number(m.doc.created) || Date.now(),
      title: String(m.doc.title || ''),
      html: String(m.doc.html || ''),
      scroll: Number(m.doc.scroll) || 0,
      md: String(m.doc.md || ''),
      revision: (stored?.revision || 0) + 1,
      updated: Date.now()
    };
    await chrome.storage.local.set({
      [m.key]: doc
    });
    return {
      ok: true,
      doc,
      sync: {
        state: 'off'
      }
    };
  }).then(reply).catch(() => reply({
    ok: false,
    error: true
  }));
  return true;
});
