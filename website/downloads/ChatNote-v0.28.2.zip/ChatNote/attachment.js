// Uses the site's ordinary file-input / paste handlers. Never submits the composer.
const ChatNoteAttachments = (() => {
  const attempts = new Map();
  const visible = el => !!el?.isConnected && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
  function composer() {
    const el = [...document.querySelectorAll('#prompt-textarea,#mobile-composer-prompt,form textarea,form [contenteditable="true"]')]
      .find(el => !el.closest('#cg-notes-host') && visible(el));
    if (!el) return null;
    const box = el.closest('form,[data-type="unified-composer"]') || el.parentElement;
    return {el, box};
  }
  function cards(box, name) {
    return [...box.querySelectorAll('[data-file-name],[data-testid*="file"],[data-testid*="attachment"],[title],span,div')].filter(el => {
      if (!visible(el) || el.matches('input,textarea,[contenteditable="true"]') || el.closest('[contenteditable="true"]')) return false;
      const named = el.getAttribute('data-file-name') === name || el.getAttribute('title') === name || el.textContent.trim() === name;
      if (!named) return false;
      let parent = el;
      for (let i = 0; parent && i < 4 && parent !== box; i++, parent = parent.parentElement) {
        if (parent.matches('[data-file-name],[data-testid*="file-upload"],[data-testid*="attachment"]') || [...parent.querySelectorAll('button')].some(b => /remove|delete|移除|删除/i.test(b.getAttribute('aria-label') || b.textContent))) return true;
      }
      return false;
    });
  }
  function acceptsMarkdown(input) {
    const accepted = (input.accept || '').toLowerCase().split(',').map(s => s.trim());
    return !input.disabled && (accepted.includes('') || accepted.some(s => ['*/*','text/*','text/plain','text/markdown','.md','.markdown','.txt','application/octet-stream'].includes(s)));
  }
  async function add(file, isCurrent) {
    const target = composer();
    if (!target) throw new Error('未找到聊天输入框，请刷新页面后重试');
    const {el, box} = target;
    const body = await file.text();
    if (!isCurrent()) return {cancelled:true};
    const existing = cards(box, file.name);
    if (existing.length) {
      if (attempts.get(file.name) === body) return {message:'这份文档已在输入框中'};
      throw new Error('输入框已有同名附件，请先移除旧附件，再添加最新版');
    }
    const inputs = [...document.querySelectorAll('input[type="file"]')].filter(acceptsMarkdown);
    const input = inputs.find(n => box.contains(n)) || (inputs.length === 1 ? inputs[0] : null);
    const transfer = new DataTransfer();
    transfer.items.add(file);
    const before = new Set(cards(box, file.name));
    // Observe the real queue before dispatch, including synchronous site handlers.
    const queued = new Promise((resolve, reject) => {
      let ended = false;
      const finish = (error, value) => {
        if (ended) return; ended = true;
        clearTimeout(timeout); clearInterval(poll); observer.disconnect();
        error ? reject(error) : resolve(value);
      };
      const inspect = () => {
        if (!isCurrent()) return finish(null, {cancelled:true});
        if (!box.isConnected || !el.isConnected) return finish(new Error('聊天输入区已变化，请重试'));
        const found = cards(box, file.name).find(n => !before.has(n));
        if (found) {
          const item = found.closest('[data-file-name],[data-testid*="file-upload"],[data-testid*="attachment"]') || found.parentElement;
          if (/upload failed|unsupported|上传失败|不支持此文件|上传出错/i.test(item.textContent)) return finish(new Error('文件上传失败，请检查输入框中的提示后重试'));
          attempts.set(file.name, body);
          finish(null, {message:'已添加到输入框，上传完成后可发送', composer:el});
        }
      };
      const observer = new MutationObserver(inspect);
      observer.observe(box, {childList:true, subtree:true, attributes:true, characterData:true});
      const poll = setInterval(inspect, 100);
      const timeout = setTimeout(() => finish(new Error('未确认附件加入，请检查输入框；如未出现，请重试或手动添加文件')), 8000);
      try {
        if (input) {
          input.files = transfer.files;
          input.dispatchEvent(new Event('change', {bubbles:true, composed:true}));
        } else {
          // Some versions mount the native file input only when its menu is open.
          el.dispatchEvent(new ClipboardEvent('paste', {clipboardData:transfer, bubbles:true, cancelable:true, composed:true}));
        }
        inspect();
      } catch (error) {finish(new Error('无法添加附件：' + error.message));}
    });
    return queued;
  }
  return {add};
})();
